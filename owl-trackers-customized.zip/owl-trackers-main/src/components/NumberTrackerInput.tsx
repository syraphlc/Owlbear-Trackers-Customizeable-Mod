import { InputHTMLAttributes } from "react";
import { getBackgroundColor } from "../colorHelpers";
import { Tracker } from "../TrackerZod";
import PartiallyControlledInput from "./PartiallyControlledInput";
import { cn } from "../lib/utils";

export default function NumberTrackerInput({
  tracker,
  color,
  updateHandler,
  inputProps,
  animateOnlyWhenRootActive = false,
}: {
  tracker: Tracker;
  color: number;
  updateHandler: (content: string) => void;
  inputProps?: InputHTMLAttributes<HTMLInputElement>;
  animateOnlyWhenRootActive?: boolean;
}): React.JSX.Element {
  if (tracker.variant !== "value")
    throw new Error("Expected value tracker variant");

  const animationDuration300 = animateOnlyWhenRootActive
    ? "group-focus-within/root:duration-300 group-hover/root:duration-300"
    : "duration-300";

  const Input = (
    <PartiallyControlledInput
      {...inputProps}
      parentValue={tracker.value.toString()}
      onUserConfirm={(target) => updateHandler(target.value)}
      className="h-[44px] w-full bg-transparent text-center outline-hidden"
      clearContentOnFocus
    />
  );

  return (
    <div className="group text-text-primary dark:text-text-primary-dark">
      <div className="grid">
        <div
          className={cn(
            animationDuration300,
            "text-2xs col-start-1 row-start-1 min-h-[14.5px] max-w-[44px] overflow-clip text-center text-nowrap opacity-0 transition-opacity group-focus-within:opacity-100",
          )}
        >
          {tracker.value}
        </div>
        <div
          className={cn(
            animationDuration300,
            "text-2xs col-start-1 row-start-1 min-h-[14.5px] max-w-[44px] overflow-clip text-center text-nowrap opacity-100 transition-opacity group-focus-within:opacity-0",
          )}
        >
          {tracker.name}
        </div>
      </div>

      <div
        className={cn(
          getBackgroundColor(color),
          "h-[44px] w-[44px] rounded-2xl",
        )}
      >
        {Input}
      </div>
    </div>
  );
}
